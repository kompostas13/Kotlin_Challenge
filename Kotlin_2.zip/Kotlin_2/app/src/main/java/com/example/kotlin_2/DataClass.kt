package com.example.kotlin_2

class DataClass : ArrayList<Data_ClassItem>(){


}
