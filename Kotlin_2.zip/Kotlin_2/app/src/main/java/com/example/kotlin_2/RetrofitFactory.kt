package com.example.kotlin_2

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object RetrofitFactory {
    //RETROFIT SERVICE CREATION
    const val BASE_URL = "https://xegr-geography.herokuapp.com/places/"

    fun makeRetrofitService(): ApiInterface {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(MoshiConverterFactory.create())
            .build().create(ApiInterface::class.java)
    }
}