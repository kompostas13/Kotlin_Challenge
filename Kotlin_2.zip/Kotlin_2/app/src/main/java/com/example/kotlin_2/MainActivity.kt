package com.example.kotlin_2

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.graphics.red
import androidx.core.view.get
import kotlinx.coroutines.*
import okhttp3.internal.wait




class MainActivity : AppCompatActivity() {
    lateinit var autocomplete: AutoCompleteTextView
    var res: MutableList<String> = ArrayList()
    lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val title = findViewById<TextView>(R.id.Title_Edit_Text)
        val price = findViewById<TextView>(R.id.Price_Edit_Text)
        val description = findViewById<TextView>(R.id.Description_Edit_text)
        val clear_button = findViewById<Button>(R.id.Clear_Button)
        val submit_button = findViewById<Button>(R.id.Submit_Button)
        autocomplete = findViewById(R.id.Location_Autocomplete)
        autocomplete.threshold = 3
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, res)
        autocomplete.setAdapter(adapter)
        var completion = false

        Log.d("ADAPTER CREATE", "HERE")

        autocomplete.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {// LOGIC WILL BE EXECUTED WHEN TEXT IS CHANGED
                if (autocomplete.text.toString().length > 2 && !completion) { //FIRST PARAMETER ENSURES WE WILL NON REQUEST DATA FOR LESS THAN 3 CHARACTERS AND SECOND PARAMETER ENSURES WE KEEP REQUESTING DATA WHEN USER HASN'T SELECT A VALID LOCATION
                    GlobalScope.launch(Dispatchers.IO) {

                        Log.d("RES MUST BE EMPTY", res.size.toString())
                        get_Async(autocomplete.text.toString())//CALL FUNCTION FOR REQUESTING DATA
                        Log.d("RES MUST BE FULL", res.size.toString())


                    }
                } else if (completion) {//IF USER SELECTED A VALID LOCATION AND CHANGED TEXT FLAG "completion" WILL BE SET TO FALSE SO WE CAN REQUEST DATA AGAIN

                    completion = false

                }

            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })


        Log.d("IN MAIN ", "HERE")

        submit_button.setOnClickListener {
            Log.d("TITLE TEXT IS", title.text.toString())
            if (completion && !title.text.isBlank()) {//THE SUBMISSION IS VALID ONLY IF TITLE AND LOCATION ARE VALID
                val rec = Record(//CREATE RECORD
                    title.text.toString(),
                    autocomplete.text.toString(),
                    price.text.toString(),
                    description.text.toString()
                )
                Log.d("SUCCESSFULL SUBMITTION", "HERE")
                Toast.makeText(this, rec.Send_json().toString(), Toast.LENGTH_LONG).show()//CREATE JSON OBJECT


            } else {
                Toast.makeText(this, "Something went wrong. Try again!", Toast.LENGTH_LONG).show()//INFORM USER FOR INVALID DATA
            }
            //CLEAR FIELDS
            title.text = ""
            autocomplete.text.clear()
            price.text = ""
            description.text = ""

        }

        clear_button.setOnClickListener {
            //CLEAR FIELDS
            title.text = ""
            autocomplete.text.clear()
            price.text = ""
            description.text = ""
            Toast.makeText(this, "Fields cleared!", Toast.LENGTH_LONG).show()
        }

        autocomplete.setOnItemClickListener { adapterView, view, i, l ->
            //IF LOCATION IS SELECTED "completion" WILL BE SET TO TRUE SO WE DON'T REQUEST DATA (SEE OnTextChanged())
            completion = true
            autocomplete.dismissDropDown()
            autocomplete.clearFocus()
            Log.d("FOCUS IS ", autocomplete.isFocused.toString())

        }
        autocomplete.setOnFocusChangeListener { view, b ->

            if (autocomplete.isFocused && !completion) {
                autocomplete.showDropDown()
            }

        }


    }


    private suspend fun get_Async(input: String) {

        try {

            withContext(Dispatchers.IO) {
                res.clear()
                Log.d("START OF GET ASYNC", "HERE")
                val data = async {

                    RetrofitFactory.makeRetrofitService().get_Data("autocomplete?input=" + input)//MAKE REQUEST TO API

                }

                if (data.await() != null) {//WAIT FOR DATA TO BE FETCHED
                    res.clear()

                    for (d in data.await().body()!!) {
                        //adapter.notifyDataSetChanged()
                        Log.d("ASYNC HERE", d.mainText.toString())
                        res += (d.mainText + " , " + d.secondaryText)//ADD LOCATION TO ARRAY FOR ADAPTER

                    }

                    GlobalScope.launch(Dispatchers.Main) {//RUN IN MAIN THREAD TO MANIPULATE ADAPTER

                        Log.d("DONE ", res.size.toString())
                        adapter = ArrayAdapter(
                            this@MainActivity,
                            android.R.layout.simple_list_item_1,
                            res
                        )


                        autocomplete.setAdapter(adapter)
                        adapter.notifyDataSetChanged()
                        if (input.length >= 3) {
                            autocomplete.showDropDown()


                        } else {
                            autocomplete.dismissDropDown()
                        }


                    }

                } else {
                    Log.d("ERROR ", "IN ELSE")
                }
            }


        } catch (e: Exception) {
            Log.d("ERROR ", "HERE")

        }
    }

}