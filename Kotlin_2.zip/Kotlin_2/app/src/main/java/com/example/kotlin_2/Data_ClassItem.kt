package com.example.kotlin_2

import com.google.gson.annotations.SerializedName

data class Data_ClassItem(
    //DATA CLASS FOR LOCATION DATA

    @SerializedName("mainText")
    val mainText: String?,
    @SerializedName("placeId")
    val placeId: String?,
    @SerializedName("secondaryText")
    val secondaryText: String?
)
