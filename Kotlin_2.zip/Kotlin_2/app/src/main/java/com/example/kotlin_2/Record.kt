package com.example.kotlin_2

import android.util.Log
import com.google.gson.Gson

data class Record(
    val title : String,
    val location : String,
    val price : String,
    val description : String
)
{
    val json :String

    init {
        val gson = Gson()
        json = gson.toJson(this)

    }

    fun Send_json() : String{
        Log.d("NEW ENTRY ", json)
        return json
    }
}
