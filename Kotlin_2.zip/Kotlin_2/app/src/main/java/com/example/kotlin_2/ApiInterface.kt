package com.example.kotlin_2

import android.util.Log
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Url

interface ApiInterface {
    //GET REQUEST
    @GET
    suspend fun get_Data(@Url url: String) : Response<Array<Data_ClassItem>>

}